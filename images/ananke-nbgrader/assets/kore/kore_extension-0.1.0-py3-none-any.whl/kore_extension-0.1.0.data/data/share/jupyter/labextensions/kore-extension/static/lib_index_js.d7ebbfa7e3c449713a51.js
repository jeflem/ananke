"use strict";
(self["webpackChunkkore_extension"] = self["webpackChunkkore_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'kore-extension', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);



// Is this the proper style? Check if there is a more fitting one or create own.
const TOP_AREA_CSS_CLASS = 'jp-Cell';
/**
 * Initialization data for the kore-extension extension.
 */
const plugin = {
    id: 'kore-extension:plugin',
    description: 'A JupyterLab extension to expand the eponymous service for course management and grade handling between LMS and JupyterHub via LTI 1.3.',
    autoStart: true,
    activate: async (app) => {
        console.log('JupyterLab extension kore-extension is activated!');
        const { commands } = app;
        // Helper function for HTTP requests to the kore service (see kore.py).
        async function executeOperation(operation, context, path) {
            console.log(`Executing asynchronous function with operation: ${operation}; context: ${context}`);
            // Defining map for operation -> HTTP method to use.
            const methodMap = {
                import: 'GET',
                get: 'GET',
                copy: 'POST',
                backup: 'PUT',
                reset: 'PATCH',
                delete: 'DELETE',
                remove: 'DELETE'
            };
            const method = methodMap[operation];
            // Check if valid operation was supplied.
            if (!method) {
                console.error(`Invalid operation: ${operation}`);
                _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Notification.error(`Invalid operation: ${operation}`, { autoClose: false });
                return;
            }
            // Defining map for context -> routes (see kore.py) to use.
            const routeMap = {
                title: 'title',
                course: 'courses',
                courses: 'courses',
                assignment: 'assignments',
                assignments: 'assignments',
                problem: 'problems',
                problems: 'problems',
            };
            const route = routeMap[context];
            // Check if valid context was supplied.
            if (!route) {
                console.error(`Invalid context: ${context}`);
                _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Notification.error(`Invalid context: ${context}`, { autoClose: false });
                return;
            }
            const requestOptions = { method };
            if (method !== 'GET') {
                requestOptions.body = JSON.stringify({ 'path': path });
            }
            return (0,_handler__WEBPACK_IMPORTED_MODULE_2__.requestAPI)(route, requestOptions)
                .then(response => {
                console.log(response.message);
                _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Notification.success(`${response.message}`, { autoClose: false });
                return response;
            })
                .catch(reason => {
                if (reason.message === 'NoContentFound') {
                    console.log(`No ${route} found that could be copied. Contact administrator or see logs for more details.`);
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Notification.info(`No ${route} found that could be copied. Contact administrator or see logs for more details.`, { autoClose: false });
                }
                else {
                    console.error(`${reason.message} while ${context} ${operation}. Contact administrator or see logs for more details.`);
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Notification.error(`${reason.message} while ${context} ${operation}. Contact administrator or see logs for more details.`, { autoClose: false });
                }
            });
        }
        // Helper function for capitalizing first letter of a string.
        function capitalizeFirstLetter(str) {
            // Return original string if it's empty or undefined.
            if (!str) {
                return str;
            }
            return str.charAt(0).toUpperCase() + str.slice(1);
        }
        // Helper function for adding a command for miscellaneous functions.
        function createCommand(operation, context) {
            return {
                label: `${capitalizeFirstLetter(operation)} ${context}`,
                caption: `${capitalizeFirstLetter(operation)} current ${context}.`,
                execute: async () => {
                    if (operation === 'backup') {
                        await executeOperation(operation, context);
                    }
                    else if (operation == 'import') {
                        try {
                            let requestData = await executeOperation(operation, context);
                            const result = await _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.InputDialog.getItem({
                                title: `Select ${context} to import:`,
                                items: requestData.names,
                                okLabel: 'Import',
                            });
                            if (result.button.accept) {
                                console.log(`Importing ${context}: ${result.value}`);
                                let index = requestData.names.indexOf(result.value);
                                let path = requestData.paths[index];
                                await executeOperation('copy', context, path);
                            }
                        }
                        catch (reason) {
                            console.error(`Error while trying to copy ${context}.`);
                        }
                    }
                    // Deleting a course.
                    else if (operation == 'delete') {
                        try {
                            // Access list of available courses. Therefore alter operation to get/import, both are valid.
                            let requestData = await executeOperation('get', context);
                            // Populate dropdown menu with results.
                            const result = await _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.InputDialog.getItem({
                                title: `Select ${context} to delete:`,
                                items: requestData.names,
                                okLabel: 'Delete',
                            });
                            // Execute deletion if the delete button was accepted (clicked).
                            if (result.button.accept) {
                                console.log(`Deleting ${context}: ${result.value}`);
                            }
                        }
                        catch (reason) {
                            console.error(`Error while trying to delete ${context}.`);
                        }
                    }
                    else {
                        (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
                            title: `${operation} ${context}`,
                            body: `Are you certain that you want to ${operation} the current ${context}?`,
                            buttons: [
                                _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.cancelButton(),
                                _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton({ label: capitalizeFirstLetter(operation) })
                            ]
                        }).then(async (result) => {
                            if (result.button.accept) {
                                console.log(`${operation}ing ${context}.`);
                                await executeOperation(operation, context);
                            }
                        }).catch((reason) => {
                            console.error(`Error while trying to ${operation} ${context}.`);
                        });
                    }
                }
            };
        }
        // Create the HTML content of the courseTitleWidget.
        const courseTitle = document.createElement('div');
        courseTitle.textContent = await executeOperation('get', 'title').then(result => result.title);
        // Create the widget, apply style and add it to the top area.
        const courseTitleWidget = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Widget({ node: courseTitle });
        courseTitleWidget.id = "kore-extension-course-title";
        courseTitleWidget.addClass(TOP_AREA_CSS_CLASS);
        app.shell.add(courseTitleWidget, 'top', { rank: 1000 });
        // Helper function for sendGrades() do add an delay by default. Otherwise there may be an update issue for the pending notification. This has to be addressed later.
        async function delay(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }
        async function sendGrades() {
            console.log('Executing asynchronous function sendGrades()');
            return (0,_handler__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('grades', {
                method: 'POST'
            })
                .then(async (response) => {
                console.log(response.message);
                // Workaround for notification stuck in pending state, which is probably related to a timing issue.
                // This is handled with a delay right now but has to be addressed later.
                // After resolving the root of the problem the delay function and 'async' before reason in this .catch block may be deleted.
                await delay(500);
                return response;
            })
                .catch(async (reason) => {
                console.error(`${reason.message} while sending grades to LMS. Contact administrator or see logs for more details.`);
                // Workaround for notification stuck in pending state, which is probably related to a timing issue.
                // This is handled with a delay right now but has to be addressed later.
                // After resolving the root of the problem the delay function and 'async' before reason in this .catch block may be deleted.
                await delay(500);
                return Promise.reject(reason.message);
            });
        }
        ;
        // Command to send grades of all students of current course to the LMS.
        commands.addCommand('kore:send-grades', {
            label: 'Send all grades to LMS',
            caption: 'Used to transfer all grades of current course to LMS.',
            execute: async (args) => {
                // Double check with user to send grades.
                const result = await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
                    title: 'Confirm Send Grades',
                    body: 'Are you sure you want to send all grades to LMS?',
                    buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.cancelButton(), _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton({ label: 'Send' })]
                });
                if (result.button.accept) {
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Notification.promise(sendGrades(), {
                        pending: { message: 'Sending grades to LMS...', options: { autoClose: false } },
                        success: { message: (result) => 'Sending grades successful.' },
                        error: { message: (reason) => `Sending grades failed with ${reason}` }
                    });
                }
                else {
                    console.log('User cancelled the operation.');
                }
            }
        });
        // ImportCommand will open a dialog with a dropdown menu, where one can choose a course/assignment/problem. Which is copied to the local home directory of the formgrader.
        // Afterwards this course/assignment/problem is accessible through the 'Formgrader' in the JupyterHub.
        commands.addCommand('kore:import-course', createCommand('import', 'course'));
        commands.addCommand('kore:import-assignment', createCommand('import', 'assignment'));
        commands.addCommand('kore:import-problem', createCommand('import', 'problem'));
        commands.addCommand('kore:backup-course', createCommand('backup', 'course'));
        commands.addCommand('kore:reset-course', createCommand('reset', 'course'));
        commands.addCommand('kore:delete-course', createCommand('delete', 'course'));
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.d7ebbfa7e3c449713a51.js.map