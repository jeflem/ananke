"""Python unit tests for kore_extension."""
